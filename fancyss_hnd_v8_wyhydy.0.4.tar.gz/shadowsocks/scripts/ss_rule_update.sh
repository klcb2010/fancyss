#!/bin/sh

# fancyss script for asuswrt/merlin based router with software center

source /koolshare/scripts/base.sh
eval $(dbus export ss_basic_)
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y%m%d\ %X)】:'
RULE_FILE=/koolshare/ss/rules/rules.json.js
RULE_DIR=/koolshare/ss/rules
RULE_BACKUP_DIR="/tmp/fancyss_rule_backup.$$"
URL_MAIN="https://raw.githubusercontent.com/qxzg/Actions/3.0/fancyss_rules_ng"

run(){
	env -i PATH=${PATH} "$@"
}

rules_meta_by_key(){
	local json_file="$1"
	local key="$2"
	[ -f "${json_file}" ] || return 1
	[ -n "${key}" ] || return 1
	run jq -r --arg key "${key}" '
		def text($v):
			if $v == null then
				""
			elif ($v | type) == "string" then
				$v
			else
				($v | tostring)
			end;
		.[$key] as $item
		| [
			(text($item.name) | @base64),
			(text($item.md5) | @base64),
			(text($item.date) | @base64),
			(if $item == null then "" else (($item | tojson) | @base64) end)
		] | join("\u001f")
	' "${json_file}" 2>/dev/null
}

rules_runtime_numbers_tsv(){
	local json_file="$1"
	[ -f "${json_file}" ] || return 1
	run jq -r '
		def text($v):
			if $v == null then
				""
			elif ($v | type) == "string" then
				$v
			else
				($v | tostring)
			end;
		[
			text(.gfwlist.date),
			text(.chnroute.date),
			text(.chnlist.date),
			text(.gfwlist.count),
			text(.chnroute.count),
			text(.chnroute.count_ip),
			text(.chnlist.count)
		] | join("\u001f")
	' "${json_file}" 2>/dev/null
}

rules_backup_once(){
	[ "${rules_backup_ready}" = "1" ] && return 0
	rm -rf "${RULE_BACKUP_DIR}"
	mkdir -p "${RULE_BACKUP_DIR}" || return 1
	cp -af "${RULE_DIR}/." "${RULE_BACKUP_DIR}/" || {
		rm -rf "${RULE_BACKUP_DIR}"
		return 1
	}
	rules_backup_ready="1"
	return 0
}

rules_restore_backup(){
	[ "${rules_backup_ready}" = "1" ] || return 1
	[ -f "${RULE_BACKUP_DIR}/rules.json.js" ] || return 1
	echo_date "开始恢复更新前的规则文件..."
	rm -rf "${RULE_DIR}"
	mkdir -p "${RULE_DIR}" || return 1
	cp -af "${RULE_BACKUP_DIR}/." "${RULE_DIR}/" || return 1
	sync
	echo_date "旧规则文件恢复完成。"
	return 0
}

rules_cleanup_backup(){
	rm -rf "${RULE_BACKUP_DIR}"
	rules_backup_ready="0"
}

rules_service_enabled(){
	[ "$(dbus get ss_basic_enable)" = "1" ]
}

rules_socks_ready(){
	netstat -nlpt 2>/dev/null | grep -q '127\.0\.0\.1:23456[[:space:]]'
}

download_rule_file(){
	local url="$1"
	local output="$2"
	local downloaded="0"

	rm -f "${output}"
	# GitHub Raw直连在部分网络下会长时间卡住。插件正在运行时优先复用
	# 已验证的本地SOCKS5出口，并保留直连作为兜底。
	if rules_service_enabled && rules_socks_ready && type curl-fancyss >/dev/null 2>&1; then
		run curl-fancyss -4skL -x socks5h://127.0.0.1:23456 \
			--connect-timeout 4 --max-time 20 -o "${output}" "${url}" >/dev/null 2>&1 && downloaded="1"
	fi
	if [ "${downloaded}" != "1" ] && type curl-fancyss >/dev/null 2>&1; then
		run curl-fancyss -4skL --connect-timeout 4 --max-time 20 \
			-o "${output}" "${url}" >/dev/null 2>&1 && downloaded="1"
	fi
	if [ "${downloaded}" != "1" ]; then
		wget -4 --no-check-certificate --timeout=8 -qO "${output}" "${url}" >/dev/null 2>&1 && downloaded="1"
	fi
	[ "${downloaded}" = "1" ] && [ -s "${output}" ]
}

rules_healthcheck(){
	local scope="${1:-local}"
	run sh /koolshare/ss/ssconfig.sh rules_healthcheck "${scope}"
}

rules_reload_live(){
	run sh /koolshare/ss/ssconfig.sh reload_rules
}

rules_apply_or_recover(){
	local require_proxy_health="$1"

	if ! rules_service_enabled; then
		echo_date "fancyss当前未启用，新规则将在下次启动时加载。"
		return 0
	fi

	echo_date "使用热加载应用新规则，保留当前代理核心和已有连接..."
	if rules_reload_live && rules_healthcheck local; then
		if [ "${require_proxy_health}" != "1" ] || rules_healthcheck proxy; then
			echo_date "新规则热加载成功，代理核心未重启。"
			return 0
		fi
		echo_date "新规则热加载后代理出口检查失败，准备自动回滚。"
	else
		echo_date "新规则热加载后的本地运行状态异常，准备自动回滚。"
	fi

	if ! rules_restore_backup; then
		echo_date "规则自动回滚失败，保留现场并退出，请检查存储空间和规则目录！"
		return 1
	fi

	echo_date "使用热加载恢复旧规则..."
	if rules_reload_live && rules_healthcheck local; then
		if [ "${require_proxy_health}" != "1" ] || rules_healthcheck proxy; then
			echo_date "旧规则已恢复，代理服务恢复正常。"
			return 1
		fi
		echo_date "旧规则热加载后代理出口仍异常，执行一次完整重启恢复运行状态。"
	else
		echo_date "旧规则热加载失败，执行一次完整重启恢复运行状态。"
	fi

	run sh /koolshare/ss/ssconfig.sh restart
	if rules_healthcheck local; then
		echo_date "完整重启完成，当前使用更新前的旧规则。"
	else
		echo_date "完整重启后本地运行状态仍异常，请检查fancyss启动日志！"
	fi
	return 1
}

start_update(){
	local update_failed="0"
	local rules_changed="0"
	local rules_backup_ready="0"
	local proxy_was_healthy="0"

	# 1. 检测规则版本号文件
	if [ ! -f "${RULE_FILE}" ];then
		echo_date "没有找到规则版本号文件: rules.json.js！请尝试覆盖安装插件解决！退出！"
		echo XU6J03M6 >> /tmp/upload/ss_log.txt
		exit
	fi
	run jq --tab . "${RULE_FILE}" >/dev/null 2>&1
	if [ "$?" != "0" ];then
		echo_date "本地规则版本号文件解析失败：${RULE_FILE}！请尝试覆盖安装插件解决！退出！"
		echo XU6J03M6 >> /tmp/upload/ss_log.txt
		exit
	fi

	# 3. 准备下载文件夹
	rm -rf /tmp/fancyss_rule_download
	mkdir /tmp/fancyss_rule_download
	local rule_save_dir=/koolshare/ss/rules
	local rule_down_dir=/tmp/fancyss_rule_download

	# 只在更新前出口原本健康时，才把出口检查作为更新后的回滚条件。
	# 这样不会把更新前已经存在的节点/网络问题误判成规则更新故障。
	if rules_service_enabled && rules_healthcheck proxy >/dev/null 2>&1; then
		proxy_was_healthy="1"
	fi

	# 4. 开始更新
	echo ==================================================================================================
	echo_date "开始更新fancyss规则，请等待..."

	# 5. 先下载版本号文件
	if download_rule_file "${URL_MAIN}/rules.json.js" /tmp/rules.json.js; then
		echo_date "检测到在线版本文件，继续..."
	else
		echo_date "没有检测到在线版本，可能是访问github有问题，去大陆白名单模式试试吧！"
		rm -rf /tmp/rules.json.js
		echo XU6J03M6 >> /tmp/upload/ss_log.txt
		exit
	fi
	run jq --tab . /tmp/rules.json.js >/dev/null 2>&1
	if [ "$?" != "0" ];then
		echo_date "在线规则版本号文件解析失败：${URL_MAIN}/rules.json.js！退出！"
		rm -rf /tmp/rules.json.js
		echo XU6J03M6 >> /tmp/upload/ss_log.txt
		exit
	fi


	update_rule() {
		# $1: key in rules.json.js
		# $2: enabled (1/0)
		local key="$1"
		local enabled="$2"

		local online_meta=""
		local local_meta=""
		local online_name_b64=""
		local online_md5_b64=""
		local online_date_b64=""
		local online_obj_b64=""
		local local_name_b64=""
		local local_md5_b64=""
		local local_date_b64=""
		local local_obj_b64=""
		local online_name online_md5 online_date_cmp online_obj
		local local_date_cmp local_md5
		local tmp_file dst_file tmp_md5
		local sep="$(printf '\037')"

		if [ "${enabled}" != "1" ]; then
			echo_date "你并没有勾选${key}更新！"
			return 0
		fi

		online_meta="$(rules_meta_by_key /tmp/rules.json.js "${key}")" || online_meta=""
		IFS="${sep}" read -r online_name_b64 online_md5_b64 online_date_b64 online_obj_b64 <<-EOF
		${online_meta}
		EOF
		[ -n "${online_name_b64}" ] && online_name="$(printf '%s' "${online_name_b64}" | base64_decode 2>/dev/null)"
		[ -n "${online_md5_b64}" ] && online_md5="$(printf '%s' "${online_md5_b64}" | base64_decode 2>/dev/null)"
		[ -n "${online_date_b64}" ] && online_date_cmp="$(printf '%s' "${online_date_b64}" | base64_decode 2>/dev/null | sed 's/[[:space:]]/_/g')"
		[ -n "${online_obj_b64}" ] && online_obj="$(printf '%s' "${online_obj_b64}" | base64_decode 2>/dev/null)"

		if [ -z "${online_name}" ] || [ "${online_name}" = "null" ]; then
			echo_date "在线版本文件缺少字段：.${key}.name，跳过！"
			return 1
		fi
		if [ -z "${online_md5}" ] || [ "${online_md5}" = "null" ]; then
			echo_date "在线版本文件缺少字段：.${key}.md5，跳过！"
			return 1
		fi
		if [ -z "${online_date_cmp}" ] || [ "${online_date_cmp}" = "null" ]; then
			echo_date "在线版本文件缺少字段：.${key}.date，跳过！"
			return 1
		fi

		local_meta="$(rules_meta_by_key "${RULE_FILE}" "${key}")" || local_meta=""
		IFS="${sep}" read -r local_name_b64 local_md5_b64 local_date_b64 local_obj_b64 <<-EOF
		${local_meta}
		EOF
		[ -n "${local_md5_b64}" ] && local_md5="$(printf '%s' "${local_md5_b64}" | base64_decode 2>/dev/null)"
		[ -n "${local_date_b64}" ] && local_date_cmp="$(printf '%s' "${local_date_b64}" | base64_decode 2>/dev/null | sed 's/[[:space:]]/_/g')"
		if [ -z "${local_date_cmp}" ] || [ "${local_date_cmp}" = "null" ]; then
			local_date_cmp="0"
		fi
		if [ -z "${local_md5}" ] || [ "${local_md5}" = "null" ]; then
			local_md5="0"
		fi

		echo_date "--------------------------------------------------------------------"
		if [ "${local_date_cmp}" = "${online_date_cmp}" ] && [ "${force_update}" != "1" ]; then
			echo_date "检测到${key}本地版本号和在线版本号相同，不进行更新!"
			return 0
		fi

		echo_date "检测到新版本${key}，开始更新..."
		echo_date "下载${online_name}到临时文件..."

		tmp_file="${rule_down_dir}/${online_name}"
		dst_file="${rule_save_dir}/${online_name}"
		rm -rf "${tmp_file}"

		if ! download_rule_file "${URL_MAIN}/${online_name}" "${tmp_file}"; then
			echo_date "${online_name}下载失败！"
			rm -rf "${tmp_file}"
			return 1
		fi

		tmp_md5="$(md5sum "${tmp_file}" | awk '{print $1}')"
		if [ "${tmp_md5}" != "${online_md5}" ]; then
			echo_date "下载完成，但校验未通过！本地md5：${tmp_md5}，在线md5：${online_md5}"
			rm -rf "${tmp_file}"
			return 1
		fi

		if ! rules_backup_once; then
			echo_date "无法备份当前规则，取消覆盖：${dst_file}"
			return 1
		fi

		echo_date "下载完成，校验通过，覆盖到：${dst_file}"
		mv "${tmp_file}" "${dst_file}"
		if [ "$?" != "0" ]; then
			echo_date "覆盖规则文件失败：${dst_file}"
			return 1
		fi
		rules_changed="1"

		if [ -n "${online_obj}" ] && [ "${online_obj}" != "null" ]; then
			local tmp_rule_json="${rule_down_dir}/rules.${key}.json.js"
			rm -rf "${tmp_rule_json}"
			run jq --argjson obj "${online_obj}" ".${key} = \$obj" "${RULE_FILE}" > "${tmp_rule_json}"
			if [ "$?" != "0" ] || [ ! -s "${tmp_rule_json}" ]; then
				echo_date "更新规则版本号文件失败：${RULE_FILE}（.${key}）"
				rm -rf "${tmp_rule_json}"
				return 1
			fi
			mv "${tmp_rule_json}" "${RULE_FILE}"
		fi

		echo_date "【更新成功】你的${key}已经更新到最新！"
		return 0
	}

	# 用户可选更新项（UI上有勾选项）
	update_rule "gfwlist" "${ss_basic_gfwlist_update}" || update_failed="1"
	update_rule "chnroute" "${ss_basic_chnroute_update}" || update_failed="1"
	update_rule "chnlist" "${ss_basic_chnlist_update}" || update_failed="1"

	# 必要/常用规则：无UI开关，默认跟随规则更新
	update_rule "chnroute6" "1" || update_failed="1"
	update_rule "adslist" "1" || update_failed="1"
	update_rule "rotlist" "1" || update_failed="1"
	update_rule "white_list" "1" || update_failed="1"
	update_rule "black_list" "1" || update_failed="1"
	update_rule "block_list" "1" || update_failed="1"
	update_rule "apple_china" "1" || update_failed="1"
	update_rule "google_china" "1" || update_failed="1"
	update_rule "cdn_test" "1" || update_failed="1"

	echo_date " --------------------------------------------------------------------"
	rm -rf /tmp/rules.json.js
	
	if [ "${update_failed}" = "1" ]; then
		echo_date "本次规则更新存在失败项，放弃整批更新并恢复原规则。"
		if [ "${rules_changed}" = "1" ]; then
			rules_restore_backup || echo_date "旧规则恢复失败，请立即检查规则目录！"
		fi
		rules_cleanup_backup
		rm -rf /tmp/fancyss_rule_download
		echo_date "规则更新进程结束：未应用不完整的规则。"
		echo ==================================================================================================
		return 1
	fi

	echo_date "规则更新进程运行完毕！"
	# write number
	IFS="$(printf '\037')" read -r rule_gfw_date rule_chnroute_date rule_chnlist_date rule_gfw_count rule_chnroute_count rule_chnroute_ip_count rule_chnlist_count <<-EOF
	$(rules_runtime_numbers_tsv "${RULE_FILE}")
	EOF
	nvram set update_gfwlist="${rule_gfw_date}"
	nvram set update_chnroute="${rule_chnroute_date}"
	nvram set update_chnlist="${rule_chnlist_date}"
	
	nvram set gfwlist_numbers="${rule_gfw_count}"
	nvram set chnroute_numbers="${rule_chnroute_count}"
	nvram set chnroute_ips="${rule_chnroute_ip_count}"
	nvram set chnlist_numbers="${rule_chnlist_count}"
	#======================================================================
	# 在线热加载，避免规则更新无条件重启代理核心造成现有连接断开。
	if [ "${rules_changed}" = "1" ];then
		if ! rules_apply_or_recover "${proxy_was_healthy}"; then
			rules_cleanup_backup
			rm -rf /tmp/fancyss_rule_download
			echo ==================================================================================================
			return 1
		fi
	fi
	rules_cleanup_backup
	rm -rf /tmp/fancyss_rule_download
	echo ==================================================================================================
	return 0
}

change_cru(){
	echo ==================================================================================================
	sed -i '/ssupdate/d' /var/spool/cron/crontabs/* >/dev/null 2>&1
	if [ "1" == "${ss_basic_rule_update}" ]; then
		echo_date "应用fancyss规则定时更新任务：每天${ss_basic_rule_update_time}:00自动检测更新规则."
		cru a ssupdate "0 ${ss_basic_rule_update_time} * * * /bin/sh /koolshare/scripts/ss_rule_update.sh"
	else
		echo_date "fancyss规则定时更新任务未启用！"
	fi
}

case $1 in
force)
	ss_basic_gfwlist_update=1
	ss_basic_chnroute_update=1
	ss_basic_chnlist_update=1
	force_update=1
	start_update
	;;
update)
	ss_basic_gfwlist_update=1
	ss_basic_chnroute_update=1
	ss_basic_chnlist_update=1
	force_update=0
	start_update
	;;
*)
	change_cru
	start_update
	;;
esac

case $2 in
1)
	true > /tmp/upload/ss_log.txt
	http_response "$1"
	change_cru > /tmp/upload/ss_log.txt
	echo XU6J03M6 >> /tmp/upload/ss_log.txt
	;;
2)
	true > /tmp/upload/ss_log.txt
	http_response "$1"
	ss_basic_gfwlist_update=1
	ss_basic_chnroute_update=1
	ss_basic_chnlist_update=1
	force_update=0
	change_cru > /tmp/upload/ss_log.txt
	start_update >> /tmp/upload/ss_log.txt
	echo XU6J03M6 >> /tmp/upload/ss_log.txt
	;;
esac
